import React from 'react'

function Preference() {
  return (
    <div className='d-flex h-100 justify-content-center align-items-center'>
      <h2>Preference Page is under development</h2>
    </div>
  )
}

export default Preference