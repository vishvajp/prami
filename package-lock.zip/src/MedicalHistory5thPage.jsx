import React from "react";

const MedicalHistory5thPage = () => {
  return (
    <div>
        <div className="d-flex flex-column gap-3">
      <div className="row">
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Power</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
       
          ></textarea>
        </div>
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Knee Jerk</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
       
          ></textarea>
        </div>
      </div>
      <div className="row">
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Tone</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
        
          ></textarea>
        </div>
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Ankle Jerk</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
         
          ></textarea>
        </div>
      </div>
      <div className="row">
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Reflexes</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
      
          ></textarea>
        </div>
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Tibialis Posterior Reflex</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
 
          ></textarea>
        </div>
      </div>
      <div className="row">
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Biceps Jerk</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
          
          ></textarea>
        </div>
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">SLR</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
        
          ></textarea>
        </div>
      </div>
      <div className="row">
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Supinator Jerk</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
       
          ></textarea>
        </div>
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Pheripheral Pulse</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
           
          ></textarea>
        </div>
      </div>
      <div className="row">
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Triceps Jerk</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
         
          ></textarea>
        </div>
        <div className="col d-flex flex-column  ">
          <label className="medichistory-lable">Special Tests</label>
          <textarea
            className="medicalhistory-5th-page-textarea"
           
          ></textarea>
        </div>
      </div>
      </div>
    </div>
  );
};

export default MedicalHistory5thPage;
